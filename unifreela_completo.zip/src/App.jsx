import React from 'react';
function App() {
  return <h1>UniFreela: Plataforma em desenvolvimento</h1>;
}
export default App;