import React from 'react';
function Home() {
  return <div>Página Home - conteúdo multilíngue aqui</div>;
}
export default Home;