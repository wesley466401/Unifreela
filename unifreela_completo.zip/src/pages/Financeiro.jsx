import React from 'react';
function Financeiro() {
  return <div>Painel Financeiro (Freelancer)</div>;
}
export default Financeiro;